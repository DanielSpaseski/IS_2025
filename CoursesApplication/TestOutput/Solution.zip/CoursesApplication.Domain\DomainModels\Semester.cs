namespace CoursesApplication.Domain.DomainModels;

public class Semester : BaseEntity
{ 
    public string Name { get; set; }
}